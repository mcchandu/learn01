# ansible-vmware-deploy-vm
Deploys a VM in VCenter using ansible modules

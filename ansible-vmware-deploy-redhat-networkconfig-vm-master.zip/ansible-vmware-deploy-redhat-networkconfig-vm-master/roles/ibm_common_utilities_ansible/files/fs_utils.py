#!/usr/libexec/platform-python

#import getopt
import os,sys

input_lenght = len(sys.argv)

#Check if all the parameters are passed with a rudimental check on the lenght
if input_lenght < 5:
    sys.exit(2)

folder_path = sys.argv[2]
required_size = sys.argv[4]

#Check if teh string are assigned.
if not folder_path or not required_size:
    sys.exit(2)
#Check if size is an integer
try: 
    tmp_int = int(required_size)
    if tmp_int <1:
       sys.exit(2)
except ValueError:
   sys.exit(2)

print ('ARGV      :', sys.argv[1:])
print ('path   :', folder_path)
print ('required_size   :', required_size)

path_s = os.statvfs(folder_path)
diskusage = path_s.f_bavail * path_s.f_frsize

print ('DISK USAGE: ', diskusage)
int_size = int(required_size) * 1024 * 1024

print ('Size as integer: ', int_size)

if(diskusage > int_size):
    print ('Exiting well')
    sys.exit()
else:
    print ('Exiting badly')
    sys.exit(1)

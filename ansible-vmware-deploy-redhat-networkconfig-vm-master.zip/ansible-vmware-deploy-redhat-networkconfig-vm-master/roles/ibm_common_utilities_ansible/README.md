ibm_commmon_utilities_ansible
=========

Role providing common utilities for the patterns roles.

Requirements
------------

None

Role tasks
-------------

## ibm_common_utilities_ansible::create_fs_volume


create_fs_volume (create_fs_volume.yml)
This task will create a volume and format it as specified by the caller on Linux platforms.

*STEPS*

- Get the LVM2 library dependency if missing on the target system (yum module)

- Create the logical volume group (lvg module)

- Create the logical volume associated with the voluem group (lvol module)

- Create the filesystem (filesystem module)

- Mount the filesystem (mount module)

---

## ibm_common_utilities_ansible::check_space


check_space (check_space.yml)
This task will check available space on the passed path and compare it with the required free space on Linux platforms.
In case the path does not have the required free space the task fails.

*STEPS*

- Invoke the Python os.statvfs(...) to get the free space for the path specified.

- Check the returned free space against the passed required space and in case there is less fee space than required it exits with a non zero return code.

---

## ibm_common_utilities_ansible::check_space_win


check_space_win (check_space_win.yml)
This task will check available space on the passed path and compare it with the required free space on Windows platforms.
In case the path does not have the required free space the task fails.

*STEPS*

- Invoke the powershell Get-Volume to get the free space for the path specified.

- Check the returned free space against the passed required space and in case there is less fee space than required it exits with a non zero return code.


Role Variables
--------------

_Free space check_

* `ibm_rs_utils_check_path` - The path on the target to be evaluated for available space. Defaults to `""`.
* `ibm_rs_utils_required_size` - The required free space required on the target path (in bytes). Defaults to `0`.

_Volume management_

* `ibm_rs_utils_physical_disk_name` - Name of the physical disk. Defaults to `sdb`.
* `ibm_rs_utils_pv_name` - Name of the physical volume name. Defaults to `/dev/sdb`.
* `ibm_rs_utils_vg_name` - Name of the volume group. Defaults to `vg_rsutils`.
* `ibm_rs_utils_mountpoint` - Path where the disk will be mounted. Defaults to `/tmp/rsutils`.
* `ibm_rs_utils_lv_name` - Name of the logical volume. Defaults to `RSUTIL`.
* `ibm_rs_utils_filesystem_type` - Filesystem type. Defaults to `ext4`.
* `ibm_rs_utils_lv_size` - Logical volume size. Defaults to `3G`.


Dependencies
------------

The role relies on powershell on Windows and Python on Linux.

Example Playbooks
----------------

_Check Disk space on Linux_

```
    - hosts: servers
      tasks:
    - name: Check if there are {{ my_required_size }} bytes available on {{ my_path }}
      import_role:
        name: ibm_common_utilities_ansible
        tasks_from: check_space
      vars:
        - ibm_rs_utils_check_path: "{{ my_path }}"
        - ibm_rs_utils_required_size: "{{ my_required_size }}"
```

_Check Disk space on Windows_

```
    - hosts: servers
      tasks:
    - name: Check if there are {{ my_required_size }} bytes available on {{ my_path }}
      import_role:
        name: ibm_common_utilities_ansible
        tasks_from: check_space_win
      vars:
        - ibm_rs_utils_check_path: "{{ my_path }}"
        - ibm_rs_utils_required_size: "{{ my_required_size }}"
```

_Create filsyetem and volume on Linux_

```
    - hosts: servers
      tasks:
    - name: Create a volume and a filesystem on it
      import_role:
        name: ibm_common_utilities_ansible
        tasks_from: create_fs_volume
      vars:
        - ibm_rs_utils_vg_name: "{{ my_vg_name }}"
        - ibm_rs_utils_pv_name: "{{ my_pv_name }}"
        - ibm_rs_utils_lv_name: "{{ my_lv_name }}"
        - ibm_rs_utils_lv_size: "{{ my_lv_size }}"
        - ibm_rs_utils_filesystem_type: "{{ my_filesystem_type }}"
        - ibm_rs_utils_mountpoint: "{{ my_mountpoint }}"

```


For more details see the related project repository.

License
-------

Copyright IBM Corp. 2019

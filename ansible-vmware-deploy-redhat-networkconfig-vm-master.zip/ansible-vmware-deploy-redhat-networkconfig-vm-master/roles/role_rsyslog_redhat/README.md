Ansible Role: role_rsyslog_redhat
=========

This role configures rsyslog on RedHat platform

Requirements
------------

It supports the following platforms

```yaml
Redhat:
  versions:
    - 7.6+
```

Role Variables
--------------

```yaml
# rsyslog custom configuration file
rsyslog_custom_configuration_file: 'files/rsyslog.conf'
```

Dependencies
------------
It requires **rsyslog** to be installed on the target machine with the configuration file */etc/rsyslog.conf*

Example Playbook
----------------

```yaml
---
- name: Play to configure rsyslog on Redhat
  hosts: all
  gather_facts: True
  become: True
  vars:
    rsyslog_custom_configuration_file: 'files/rsyslog.conf'
  tasks:
    - name: Importing the role for configuring rsyslog on Redhat
      include_role:
        name: role_rsyslog_redhat

  post_tasks:
    - name: Log the evidence
      include_role:
        name: role_rsyslog_redhat
        tasks_from: gather_evidence


```

License
-------

Copyright:: 2019, IBM Corp

License:: Copyright IBM Corp. 2019, 2019

Author Information
------------------

Author:: IBM Corp (<>)